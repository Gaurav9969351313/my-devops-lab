package com.example.c2btester;

import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@Slf4j
@EnableBatchProcessing
public class C2bTesterApplication {

	public static void main(String[] args) {
		SpringApplication.run(C2bTesterApplication.class, args);
	}

}
