package com.example.c2btester.batch;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.example.c2btester.batch.exceptions.CommonStepsExceptionHandler;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Configuration
public class JobConfiguration {
    
    private final JobBuilderFactory jobBuilderFactory;
    private final StepBuilderFactory stepBuilderFactory;
    private final CommonStepsExceptionHandler commonStepsExceptionHandler;

    public JobConfiguration(JobBuilderFactory jobBuilderFactory, StepBuilderFactory stepBuilderFactory,
            CommonStepsExceptionHandler commonStepsExceptionHandler) {
        this.jobBuilderFactory = jobBuilderFactory;
        this.stepBuilderFactory = stepBuilderFactory;
        this.commonStepsExceptionHandler = commonStepsExceptionHandler;
    }
    
    @Bean
    public Job initialize(Step deletePreviousPortfolio, Step readClientData, Step validateInputFiles) {
        return jobBuilderFactory.get("initialize")
                .start(readClientData)              
                .next(deletePreviousPortfolio)
                .next(validateInputFiles)
                .build();
    }
    
    @Bean
    public Step readClientData(Tasklet readClientDataTasklet) {
        return stepBuilderFactory.get("readClientData")
                .tasklet(readClientDataTasklet)
                .exceptionHandler(this.commonStepsExceptionHandler)
                .build();
    }
    
    @Bean
    public Step deletePreviousPortfolio(Tasklet deletePreviousPortfolioTasklet) {
        return stepBuilderFactory.get("deletePreviousPortfolio")
                .tasklet(deletePreviousPortfolioTasklet)
                .exceptionHandler(this.commonStepsExceptionHandler)
                .build();
    }
    
    @Bean
    public Step validateInputFiles(Tasklet validateInputFilesTasklet) {
        return stepBuilderFactory.get("validateInputFiles")
                .tasklet(validateInputFilesTasklet)
                .exceptionHandler(this.commonStepsExceptionHandler)
                .build();
    }
}
