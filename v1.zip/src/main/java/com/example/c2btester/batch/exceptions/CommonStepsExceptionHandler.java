package com.example.c2btester.batch.exceptions;


import org.springframework.batch.repeat.RepeatContext;
import org.springframework.batch.repeat.exception.ExceptionHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import com.example.c2btester.batch.util.ApplicationHelper;

@Component
public class CommonStepsExceptionHandler implements ExceptionHandler {

    private static final String REFERENCE = "Adapter processing failed";

    @Autowired
    private ApplicationContext context;

   
    @Override
    public void handleException(RepeatContext context, Throwable e) throws Throwable {
        String message = String.format("The processing was stopped due to exception of type: %s. "
                + "Exception message: %s", e.getClass().getName(), e.getMessage());
        System.out.println("====================== from CommonStepsExceptionHandler =============================");
        System.out.println(message);
        System.out.println("========================================================================");
        ApplicationHelper.shutDownSpringBootApplication(this.context, ApplicationHelper.FAILURE_EXIT_CODE);
    }
}

