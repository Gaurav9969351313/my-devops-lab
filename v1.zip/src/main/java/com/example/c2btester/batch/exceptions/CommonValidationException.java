package com.example.c2btester.batch.exceptions;

public class CommonValidationException extends RuntimeException {

    public CommonValidationException(Throwable cause) {
        super(cause);
    }

    public CommonValidationException(String message) {
        super(message);
    }
}
