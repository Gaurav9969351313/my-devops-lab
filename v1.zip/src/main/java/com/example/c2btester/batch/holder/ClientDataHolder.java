package com.example.c2btester.batch.holder;


import java.util.Arrays;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.example.c2btester.db.entity.ClientReferenceData;

import lombok.Setter;

@Setter
@Component
public class ClientDataHolder {

    private static final String COMMAS_BASED_DELIMITER = "\\s*,\\s*";
    public static final String ANY_SYMBOLS_AND_EXTENSION = ".*[^\\.]?\\.\\w+$";

    private ClientReferenceData clientData;
   
    public ClientReferenceData getClientData() {
        return clientData;
    }


    public void setClientData(ClientReferenceData clientData) {
        System.out.println("Step 3: ===> " + clientData);
        this.clientData = clientData;
    }


    public String getInputDirectoryPath() {
        System.out.println("Step 1 ===>" + clientData);
        return Optional.ofNullable(clientData)
                .map(ClientReferenceData::getClientBaseDir)
                .orElseThrow(() -> new RuntimeException("Missing input directory path"));
    }

   
    public String getMappingConfigPath() {
        return Optional.ofNullable(clientData)
                .map(ClientReferenceData::getConfigPath)
                .orElseThrow(() -> new RuntimeException("Missing mapping config path"));
    }

   
    public String getOutputFilePath() {
        return "C:\\D-drive\\DATA\\DMMDATA\\IMSeg\\VRS\\Trade\\c2bOutput";
//        Optional.ofNullable(clientData)
//                .map(ClientReferenceData::getOutputFilePath)
//                .orElseThrow(() -> new RuntimeException("Missing output file path"));
    }

    
    public String getTradeDataPath() {
        return Optional.ofNullable(clientData)
                .map(ClientReferenceData::getTradeDataPath)
                .orElseThrow(() -> new RuntimeException("Missing trade data path"));
    }

 
    public String getClientName() {
        return Optional.ofNullable(clientData)
                .map(ClientReferenceData::getClientName)
                .orElseThrow(() -> new RuntimeException("Missing client name"));
    }

    public Set<String> getInputFileNamePatterns() {
        return getInputFileNames().stream()
                .map(fileName -> fileName + ANY_SYMBOLS_AND_EXTENSION)
                .collect(Collectors.toSet());
    }

    public Set<String> getInputFileNames() {
        return Optional.ofNullable(clientData.getClientFileIdentifier())
                .map(fileNames -> fileNames.trim().split(COMMAS_BASED_DELIMITER))
                .map(fileNames -> new HashSet<>(Arrays.asList(fileNames)))
                .orElseThrow(() -> new RuntimeException("Missing client file identifier"));
    }
}
