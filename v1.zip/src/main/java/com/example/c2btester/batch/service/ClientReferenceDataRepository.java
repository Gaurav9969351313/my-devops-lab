package com.example.c2btester.batch.service;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.example.c2btester.db.entity.ClientReferenceData;

public interface ClientReferenceDataRepository extends CrudRepository<ClientReferenceData, Long> {

    Optional<ClientReferenceData> findFirstByClientName(String clientName);
}
