package com.example.c2btester.batch.service;

import java.util.Optional;

import com.example.c2btester.db.entity.ClientReferenceData;

public interface ClientReferenceDataService {
    Optional<ClientReferenceData> getByClientName(String name);
}