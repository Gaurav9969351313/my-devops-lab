package com.example.c2btester.batch.tasklets;

import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.stereotype.Component;

import com.example.c2btester.batch.holder.ClientDataHolder;
import com.example.c2btester.batch.util.FileUtil;

@StepScope
@Component
public class DeletePreviousPortfolioTasklet implements Tasklet {

    private final ClientDataHolder clientDataHolder;

    public DeletePreviousPortfolioTasklet(ClientDataHolder clientDataHolder) {
        this.clientDataHolder = clientDataHolder;
    }

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {
        Path path = getOutputFilePath();
        FileUtil.deleteFile(path);
        return RepeatStatus.FINISHED;
    }

    private Path getOutputFilePath() {
        String outputFilePath = clientDataHolder.getOutputFilePath();
        return Paths.get(outputFilePath);
    }
}
