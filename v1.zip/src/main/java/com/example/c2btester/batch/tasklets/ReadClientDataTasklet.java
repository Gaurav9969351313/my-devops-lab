package com.example.c2btester.batch.tasklets;


import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.logging.log4j.util.Strings;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.example.c2btester.batch.holder.ClientDataHolder;
import com.example.c2btester.batch.service.ClientReferenceDataService;
import com.example.c2btester.db.entity.ClientReferenceData;
import com.example.c2btester.db.entity.JobDataHolder;

@Component("readClientDataTasklet")
public class ReadClientDataTasklet implements Tasklet {
    private final ClientDataHolder clientDataHolder;
    private final JobDataHolder jobDataHolder;
    private final ClientReferenceDataService clientReferenceDataService;

    private final List<String> supportedClients;
    
    public ReadClientDataTasklet(ClientReferenceDataService clientReferenceDataService,
            ClientDataHolder clientDataHolder, JobDataHolder jobDataHolder,
            @Value("${supported-clients}") List<String> supportedClients) {
        this.clientReferenceDataService = clientReferenceDataService;
        this.clientDataHolder = clientDataHolder;
        this.jobDataHolder = jobDataHolder;
        this.supportedClients = supportedClients;
    }
    
    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {
        Map<String, Object> jobParameters = chunkContext.getStepContext().getJobParameters();
        String clientName = "clientName";
        String name = (String) jobParameters.get(clientName);
        validate(name);
        Optional<ClientReferenceData> opClientRefData = clientReferenceDataService.getByClientName(name);
        if (opClientRefData.isPresent()) {
            clientDataHolder.setClientData(opClientRefData.get());
        }

        return RepeatStatus.FINISHED;
    }

    private void validate(String clientName) {
        if (Strings.isBlank(clientName)) {
            throw new RuntimeException("Client name was not passed");
        }
        boolean isSupportedName = supportedClients.stream()
                .anyMatch(clientName::startsWith);
        if (!isSupportedName) {
            String message = String.format(
                    "The unsupported client name \"%s\" has been passed. Supported client name prefixes: %s",
                    clientName, supportedClients);
            throw new RuntimeException(message);
        }
    }
}
