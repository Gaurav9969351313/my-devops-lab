package com.example.c2btester.batch.tasklets;

import java.io.File;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.io.FileUtils;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import com.example.c2btester.batch.exceptions.CommonValidationException;
import com.example.c2btester.batch.holder.ClientDataHolder;
import com.example.c2btester.batch.util.SupportedExtensions;

import lombok.extern.slf4j.Slf4j;

@StepScope
@Slf4j
@Component("validateInputFilesTasklet")
public class ValidateInputFilesTasklet implements Tasklet {

    private final ClientDataHolder clientDataHolder;

    private final Set<String> fileNamePatterns;

    private final SupportedExtensions supportedExtensions;

    public ValidateInputFilesTasklet(ClientDataHolder clientDataHolder, List<SupportedExtensions> supportedExtensions) {
        this.clientDataHolder = clientDataHolder;
        this.fileNamePatterns = clientDataHolder.getInputFileNamePatterns();
        validate(supportedExtensions);
        this.supportedExtensions = getSupportedExtensions(supportedExtensions);
    }

    private void validate(List<SupportedExtensions> supportedExtensions) {
        Assert.isTrue(supportedExtensions.size() == 1,
                "Supported input files extensions configured incorrectly");
    }

    private SupportedExtensions getSupportedExtensions(List<SupportedExtensions> supportedExtensions) {
        int supportedExtensionsIndex = 0;
        return supportedExtensions.get(supportedExtensionsIndex);
    }

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {
        final String inputDirectory = clientDataHolder.getInputDirectoryPath();
        Collection<File> filesCollection = FileUtils.listFiles(new File(inputDirectory), null, false);
        File[] files = FileUtils.convertFileCollectionToFileArray(filesCollection);
        validateClientFiles(files);
        return RepeatStatus.FINISHED;
    }

    /**
     * General method to validate client files. Calls specific methods.
     *
     * @param clientFiles input files to validate
     */
    private void validateClientFiles(File[] clientFiles) {
        checkIfFilesExist(clientFiles);
        validateFileNames(clientFiles);
        validateFileExtensions(clientFiles);
        checkIfFilesAreNotEmpty(clientFiles);
    }

    /**
     * Checks existence and amount of input files.
     *
     * @param clientFiles input files to validate
     * @throws CommonValidationException If there is a difference between the amount
     *                                   of input files and the amount of input file
     *                                   name patterns
     */
    private void checkIfFilesExist(File[] clientFiles) {
        if (clientFiles == null || clientFiles.length == 0) {
            String errorMessage = "There are no input files!";
            throw new CommonValidationException(errorMessage);
        } else if (fileNamePatterns.size() != clientFiles.length) {
            Set<String> fileNames = clientDataHolder.getInputFileNames();
            String errorMessage = String
                    .format("There is a difference between the amount of input files and the amount of "
                            + "input file name patterns: %s", fileNames);
            throw new CommonValidationException(errorMessage);
        }
    }

    /**
     * Calls specific methods to validate input file names.
     *
     * @param clientFiles input files to validate
     */
    private void validateFileNames(File[] clientFiles) {
        Map<String, Integer> amountOfSuitableFileNamesForPattern = checkIfAllFilesMatchPattern(clientFiles);
        checkIfAmountOfFilesIsSuitable(clientFiles, amountOfSuitableFileNamesForPattern);
    }

    /**
     * Checks the amount of suitable files for each input file name pattern.
     * <p>
     * If any of patterns have more than 1 suitable file, then throws exception
     *
     * @param clientFiles                         input files to validate
     * @param amountOfSuitableFileNamesForPattern map of file name patterns as keys
     *                                            and amount of files from client
     *                                            files that match specified
     *                                            pattern, as value
     * @throws CommonValidationException If any of patterns have more than 1
     *                                   suitable file, then throws exception
     */
    private void checkIfAmountOfFilesIsSuitable(File[] clientFiles,
            Map<String, Integer> amountOfSuitableFileNamesForPattern) {
        final List<String> repeatedFiles = amountOfSuitableFileNamesForPattern.keySet().stream()
                .filter(pattern -> amountOfSuitableFileNamesForPattern.get(pattern) > 1)
                .map(pattern -> Arrays.stream(clientFiles)
                        .filter(file -> file.getName().matches(pattern))
                        .map(File::getName)
                        .collect(Collectors.toList()))
                .flatMap(Collection::stream)
                .collect(Collectors.toList());

        if (!repeatedFiles.isEmpty()) {
            String errorMessage = getErrorMessage(repeatedFiles, "Multiple files found");
            throw new CommonValidationException(errorMessage);
        }
    }

    /**
     * Checks if all input files match file name patterns, otherwise throws an
     * exception.
     *
     * @param clientFiles input files to validate
     * @return map of file name patterns as keys and amount of files from client
     *         files that match specified pattern, as value
     * @throws CommonValidationException If some input files mismatch file name
     *                                   patterns
     */
    private Map<String, Integer> checkIfAllFilesMatchPattern(File[] clientFiles) {
        Map<String, Integer> amountOfSuitableFileNamesForPattern = new HashMap<>();

        List<String> wrongFileNames = Arrays.stream(clientFiles)
                .map(File::getName)
                .filter(name -> fileNamePatterns.stream()
                        .noneMatch(pattern -> {
                            boolean matches = name.matches(pattern);
                            if (matches) {
                                amountOfSuitableFileNamesForPattern.merge(pattern, 1, Integer::sum);
                            }
                            return matches;
                        }))
                .collect(Collectors.toList());

        if (!wrongFileNames.isEmpty()) {
            String errorMessage = getErrorMessage(wrongFileNames, "Invalid file names");
            throw new CommonValidationException(errorMessage);
        }

        return amountOfSuitableFileNamesForPattern;
    }

    /**
     * Checks if all input files have correct extension, otherwise throws an
     * exception.
     *
     * @param clientFiles input files to validate
     * @throws CommonValidationException If some input files have an incorrect
     *                                   extension
     */
    private void validateFileExtensions(File[] clientFiles) {
        final List<String> fileNamesWrongExtension = Arrays.stream(clientFiles)
                .map(File::getName)
                .filter(name -> this.supportedExtensions.getEnums().stream()
                        .noneMatch(extension -> name.endsWith(extension.getName())))
                .collect(Collectors.toList());

        if (!fileNamesWrongExtension.isEmpty()) {
            String errorMessage = getErrorMessage(fileNamesWrongExtension, "Invalid file extensions");
            throw new CommonValidationException(errorMessage);
        }
    }

    /**
     * Checks if input files are not empty, otherwise throws an exception.
     *
     * @param clientFiles input files to validate
     * @throws CommonValidationException If input files are empty
     */
    private void checkIfFilesAreNotEmpty(File[] clientFiles) {
        final List<String> emptyFiles = Arrays.stream(clientFiles)
                .filter(file -> file.length() == 0)
                .map(File::getName)
                .collect(Collectors.toList());

        if (!emptyFiles.isEmpty()) {
            String errorMessage = getErrorMessage(emptyFiles, "Files are empty");
            throw new CommonValidationException(errorMessage);
        }
    }

    private String getErrorMessage(List<String> elements, String errorMessage) {
        if (!elements.isEmpty()) {
            return String.format("%s: %s", errorMessage, elements);
        }
        return errorMessage;
    }
}