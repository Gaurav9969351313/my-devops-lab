package com.example.c2btester.batch.util;

import java.io.IOException;
import java.util.Objects;

import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class ApachePOIUtils {

    public static void closeWorkbook(Workbook workbook) {
        if (Objects.nonNull(workbook)) {
            try {
                workbook.close();
                dispose(workbook);
            } catch (IOException e) {
                System.out.println("======> Error during Workbook closing");
            }
        }
    }

    private static void dispose(Workbook workbook) {
        if (workbook instanceof SXSSFWorkbook) {
            ((SXSSFWorkbook) workbook).dispose();
        }
    }
}
