package com.example.c2btester.batch.util;

import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;

import lombok.experimental.UtilityClass;

@UtilityClass
public class ApplicationHelper {

    public static final int FAILURE_EXIT_CODE = 1;

    public static void shutDownSpringBootApplication(ApplicationContext context, int exitCode) {
        final int exitStatus = SpringApplication.exit(context, () -> exitCode);
        System.exit(exitStatus);
    }
}