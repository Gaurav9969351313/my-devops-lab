package com.example.c2btester.batch.util;

public interface Enumerable {

    String getName();
}