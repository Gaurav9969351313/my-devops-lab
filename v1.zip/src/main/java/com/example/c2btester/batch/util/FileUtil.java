package com.example.c2btester.batch.util;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Collection;

import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Workbook;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public class FileUtil {

    private static final String XML = "xml";

    public static void saveToFile(String path, Workbook data) {
        try (FileOutputStream fileOutputStream = new FileOutputStream(path)) {
            data.write(fileOutputStream);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(String.format("Invalid output file path: %s", path));
        } catch (IOException e) {
            throw new RuntimeException(String.format("Error during writing to file: %s", path), e);
        } finally {
            ApachePOIUtils.closeWorkbook(data);
        }
    }

    public static void deleteFile(Path path) {
        try {
            Files.deleteIfExists(path);
        } catch (IOException e) {
            String message = String.format("Error during deletion an existing: \"%s\"", path);
            throw new RuntimeException(message, e);
        }
    }

    public static void createFile(Path path) {
        try {
            Files.createFile(path);
        } catch (IOException e) {
            String message = String.format("Error during tne new file creating: \"%s\"", path);
            throw new RuntimeException(message, e);
        }
    }

    public static File[] getXmlFilesFromDirectory(File directory) {
        String[] xmlExtensions = { XML };
        Collection<File> filesCollection = FileUtils.listFiles(directory, xmlExtensions, false);
        return FileUtils.convertFileCollectionToFileArray(filesCollection);
    }
}