package com.example.c2btester.batch.util;

import java.util.Set;

public interface SupportedExtensions {

    Set<Enumerable> getEnums();
}
