package com.example.c2btester.db.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "DMM_IMSEG_CLIENT_REF_DATA")
public class ClientReferenceData {

    @Id
    @Column(name = "CLIENT_NAME", length = 100)
    private String clientName;

    @Column(name = "CLIENT_BASE_DIR", length = 4000)
    private String clientBaseDir;

    @Column(name = "C2B_OUTPUT_PATH", length = 4000)
    private String outputFilePath;

    @Column(name = "C2B_CLIENT_CONFIG", length = 4000)
    private String configPath;

    @Column(name = "C2B_TRADE_CONFIG", length = 4000)
    private String tradeDataPath;

    @Column(name = "CLIENT_FILE_IDENTIFIER")
    private String clientFileIdentifier;

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getClientBaseDir() {
        return clientBaseDir;
    }

    public void setClientBaseDir(String clientBaseDir) {
        this.clientBaseDir = clientBaseDir;
    }

    public String getOutputFilePath() {
        return outputFilePath;
    }

    public void setOutputFilePath(String outputFilePath) {
        this.outputFilePath = outputFilePath;
    }

    public String getConfigPath() {
        return configPath;
    }

    public void setConfigPath(String configPath) {
        this.configPath = configPath;
    }

    public String getTradeDataPath() {
        return tradeDataPath;
    }

    public void setTradeDataPath(String tradeDataPath) {
        this.tradeDataPath = tradeDataPath;
    }

    public String getClientFileIdentifier() {
        return clientFileIdentifier;
    }

    public void setClientFileIdentifier(String clientFileIdentifier) {
        this.clientFileIdentifier = clientFileIdentifier;
    }
    
    @Override
    public String toString() {
        return "ClientReferenceData [clientName=" + clientName + ", clientBaseDir=" + clientBaseDir
                + ", outputFilePath=" + outputFilePath + ", configPath=" + configPath + ", tradeDataPath="
                + tradeDataPath + ", clientFileIdentifier=" + clientFileIdentifier + "]";
    }

    
    
    
    
}
