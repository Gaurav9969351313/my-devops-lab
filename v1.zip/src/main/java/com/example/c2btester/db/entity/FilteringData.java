
package com.example.c2btester.db.entity;

import java.util.List;
import java.util.Map;

public class FilteringData {

    private String identifier;

    private String columnPosition;

    private Map<String, String> columnAttributes;

    private List<String> columnValues;

    public String getIdentifier() {
        return identifier;
    }

    public void setIdentifier(String identifier) {
        this.identifier = identifier;
    }

    public String getColumnPosition() {
        return columnPosition;
    }

    public void setColumnPosition(String columnPosition) {
        this.columnPosition = columnPosition;
    }

    public Map<String, String> getColumnAttributes() {
        return columnAttributes;
    }

    public void setColumnAttributes(Map<String, String> columnAttributes) {
        this.columnAttributes = columnAttributes;
    }

    public List<String> getColumnValues() {
        return columnValues;
    }

    public void setColumnValues(List<String> columnValues) {
        this.columnValues = columnValues;
    }

}