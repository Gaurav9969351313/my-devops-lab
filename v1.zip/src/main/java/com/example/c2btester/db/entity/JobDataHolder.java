
package com.example.c2btester.db.entity;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.springframework.stereotype.Component;

@Component
public class JobDataHolder {

    private final String jobRunId;

    private Set<String> skipIdentifiers;

    private Map<String, List<FilteringData>> includeValues;

    private List<FilteringData> commonIncludeValues;

    private Map<String, List<FilteringData>> excludeValues;

    private List<FilteringData> commonExcludeValues;

    public JobDataHolder() {
        jobRunId = UUID.randomUUID().toString();
        System.out.println("Step 2: Run ID: " + jobRunId );
    }

    public Set<String> getSkipIdentifiers() {
        return skipIdentifiers;
    }

    public void setSkipIdentifiers(Set<String> skipIdentifiers) {
        this.skipIdentifiers = skipIdentifiers;
    }

    public Map<String, List<FilteringData>> getIncludeValues() {
        return includeValues;
    }

    public void setIncludeValues(Map<String, List<FilteringData>> includeValues) {
        this.includeValues = includeValues;
    }

    public List<FilteringData> getCommonIncludeValues() {
        return commonIncludeValues;
    }

    public void setCommonIncludeValues(List<FilteringData> commonIncludeValues) {
        this.commonIncludeValues = commonIncludeValues;
    }

    public Map<String, List<FilteringData>> getExcludeValues() {
        return excludeValues;
    }

    public void setExcludeValues(Map<String, List<FilteringData>> excludeValues) {
        this.excludeValues = excludeValues;
    }

    public List<FilteringData> getCommonExcludeValues() {
        return commonExcludeValues;
    }

    public void setCommonExcludeValues(List<FilteringData> commonExcludeValues) {
        this.commonExcludeValues = commonExcludeValues;
    }

    public String getJobRunId() {
        return jobRunId;
    }
}
