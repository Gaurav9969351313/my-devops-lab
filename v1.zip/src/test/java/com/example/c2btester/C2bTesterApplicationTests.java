package com.example.c2btester;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class C2bTesterApplicationTests {

	@Test
	void contextLoads() {
	}

}
